document.addEventListener("DOMContentLoaded", () => {
  // Function to clear saved data
  function clearSavedData() {
    // Clear form fields
    const form = document.getElementById("dataForm")
    if (form) {
      form.reset()
    }

    // Clear any stored data
    if (typeof Storage !== "undefined") {
      localStorage.removeItem("formData")
      sessionStorage.removeItem("formData")
    }

    console.log("Form data cleared")
  }

  // Make clearSavedData available globally
  window.clearSavedData = clearSavedData

  const dataForm = document.getElementById("dataForm")
  const successAlert = document.getElementById("successAlert")
  const errorAlert = document.getElementById("errorAlert")
  const errorMessage = document.getElementById("errorMessage")
  const closeAlert = document.getElementById("closeAlert")
  const closeErrorAlert = document.getElementById("closeErrorAlert")
  const downloadExcel = document.getElementById("downloadExcel")
  const downloadLink = document.getElementById("downloadLink")

  // Check if Excel file exists and update download button
  fetch("/check-file")
    .then((response) => response.json())
    .then((data) => {
      if (data.exists) {
        downloadExcel.href = "/download/data_sensus.xlsx"
        downloadExcel.classList.remove("hidden")
      }
    })
    .catch((error) => console.error("Error checking file:", error))

  // Cascading dropdown data
  const dusunData = {
    Sidopurno: {
      rt: [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 31, 32, 33, 34, 35, 36, 42, 43, 44, 45, 48,
      ],
      rw: [1, 2, 3, 4, 8],
    },
    Melaten: {
      rt: [22, 23, 24, 25, 26, 46, 47],
      rw: [6],
    },
    Ngepung: {
      rt: [27, 28, 29, 30, 37, 38, 39, 40, 41],
      rw: [7],
    },
    Duran: {
      rt: [20, 21],
      rw: [5],
    },
    "Maten Perum Grenhill": {
      rt: [49],
      rw: [6],
    },
  }

  // Function to update RT and RW options based on selected Dusun
  window.updateRTRWOptions = () => {
    const dusunSelect = document.getElementById("dusun")
    const rtSelect = document.getElementById("rt")
    const rwSelect = document.getElementById("rw")

    const selectedDusun = dusunSelect.value

    // Clear existing options
    rtSelect.innerHTML = '<option value="" disabled selected>Pilih RT</option>'
    rwSelect.innerHTML = '<option value="" disabled selected>Pilih RW</option>'

    if (selectedDusun && dusunData[selectedDusun]) {
      // Enable dropdowns
      rtSelect.disabled = false
      rwSelect.disabled = false

      // Populate RT options
      dusunData[selectedDusun].rt.forEach((rt) => {
        const option = document.createElement("option")
        option.value = rt.toString().padStart(2, "0") // Format as 01, 02, etc.
        option.textContent = rt.toString().padStart(2, "0")
        rtSelect.appendChild(option)
      })

      // Populate RW options
      dusunData[selectedDusun].rw.forEach((rw) => {
        const option = document.createElement("option")
        option.value = rw.toString().padStart(2, "0") // Format as 01, 02, etc.
        option.textContent = rw.toString().padStart(2, "0")
        rwSelect.appendChild(option)
      })
    } else {
      // Disable dropdowns if no dusun selected
      rtSelect.disabled = true
      rwSelect.disabled = true
      rtSelect.innerHTML = '<option value="" disabled selected>Pilih Dusun dulu</option>'
      rwSelect.innerHTML = '<option value="" disabled selected>Pilih Dusun dulu</option>'
    }
  }

  // Remove the old RT/RW input validation since they're now dropdowns
  // (Remove the lines that were restricting RT/RW to numbers only)

  // Validasi jumlah anggota 15+ tidak lebih dari jumlah anggota total
  document.getElementById("jumlah_anggota_15plus").addEventListener("input", function (e) {
    const totalAnggota = Number.parseInt(document.getElementById("jumlah_anggota").value) || 0
    const anggota15Plus = Number.parseInt(this.value) || 0

    if (anggota15Plus > totalAnggota) {
      this.value = totalAnggota
    }
  })

  document.getElementById("jumlah_anggota").addEventListener("input", function (e) {
    const totalAnggota = Number.parseInt(this.value) || 0
    const anggota15Plus = Number.parseInt(document.getElementById("jumlah_anggota_15plus").value) || 0

    if (anggota15Plus > totalAnggota) {
      document.getElementById("jumlah_anggota_15plus").value = totalAnggota
    }
  })

  // Check if we're coming from a redirect that should clear data
  const urlParams = new URLSearchParams(window.location.search)
  if (urlParams.get("clear") === "true") {
    // Clear any existing form data
    const form = document.getElementById("dataForm")
    if (form) {
      form.reset()
    }
    // Remove the parameter from URL
    window.history.replaceState({}, document.title, window.location.pathname)
    console.log("Form cleared due to clear parameter")
  } else {
    // Load saved form data only if not clearing
    fetch("/get-form-data")
      .then((response) => response.json())
      .then((data) => {
        if (data.form_data) {
          const formData = data.form_data
          // Fill form with saved data only if we have valid data
          Object.keys(formData).forEach((key) => {
            const element = document.getElementById(key)
            if (element && formData[key]) {
              element.value = formData[key]
            }
          })
          console.log("Form data loaded from session")
        } else {
          // Ensure form is clear for new entries
          const form = document.getElementById("dataForm")
          if (form) {
            form.reset()
          }
          console.log("No saved data found, form cleared for new entry")
        }
      })
      .catch((error) => {
        console.error("Error loading form data:", error)
        // Clear form on error
        const form = document.getElementById("dataForm")
        if (form) {
          form.reset()
        }
      })
  }

  // Form validation
  dataForm.addEventListener("submit", (e) => {
    e.preventDefault()

    // Reset error messages
    document.querySelectorAll(".text-red-500").forEach((el) => el.classList.add("hidden"))

    let isValid = true

    // Validate required fields
    const requiredFields = ["dusun", "rt", "rw", "nama_kepala", "alamat", "jumlah_anggota", "jumlah_anggota_15plus"]

    requiredFields.forEach((field) => {
      const input = document.getElementById(field)
      const error = document.getElementById(`${field}_error`)

      // For select elements, check if value is empty or null
      const isEmpty = input.tagName === "SELECT" ? !input.value || input.value === "" : !input.value.trim()

      if (isEmpty) {
        error.classList.remove("hidden")
        isValid = false

        // Add shake animation
        input.classList.add("border-red-500")
        input.animate(
          [
            { transform: "translateX(0)" },
            { transform: "translateX(-5px)" },
            { transform: "translateX(5px)" },
            { transform: "translateX(-5px)" },
            { transform: "translateX(5px)" },
            { transform: "translateX(0)" },
          ],
          {
            duration: 500,
            easing: "ease-in-out",
          },
        )

        // Remove red border after 2 seconds
        setTimeout(() => {
          input.classList.remove("border-red-500")
        }, 2000)
      }
    })

    // Additional validation for jumlah_anggota_15plus
    const totalMembers = Number.parseInt(document.getElementById("jumlah_anggota").value) || 0
    const adultMembers = Number.parseInt(document.getElementById("jumlah_anggota_15plus").value) || 0

    if (adultMembers > totalMembers) {
      document.getElementById("jumlah_anggota_15plus_error").textContent =
        "Tidak boleh lebih dari jumlah anggota keluarga"
      document.getElementById("jumlah_anggota_15plus_error").classList.remove("hidden")
      isValid = false
    }

    if (isValid) {
      // Create form data
      const formData = new FormData(dataForm)

      // Show loading state
      const submitButton = dataForm.querySelector('button[type="submit"]')
      const originalButtonText = submitButton.innerHTML
      submitButton.innerHTML = `
                <svg class="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Menyimpan...
            `
      submitButton.disabled = true

      // Send data to server
      fetch("/submit", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          // Reset button state
          submitButton.innerHTML = originalButtonText
          submitButton.disabled = false

          if (data.success) {
            // Jika perlu redirect ke halaman lanjutan
            if (data.redirect) {
              window.location.href = data.redirect_url
              return
            }

            // Show success message
            successAlert.classList.remove("hidden")
            errorAlert.classList.add("hidden")

            // Update download link
            if (data.download_url) {
              downloadLink.href = data.download_url
              downloadExcel.href = data.download_url
              downloadExcel.classList.remove("hidden")
            }

            // Reset form
            dataForm.reset()

            // Scroll to success message
            successAlert.scrollIntoView({ behavior: "smooth" })

            // Hide success message after 10 seconds
            setTimeout(() => {
              successAlert.classList.add("hidden")
            }, 10000)
          } else {
            // Show error message
            errorMessage.textContent = data.message || "Terjadi kesalahan."
            errorAlert.classList.remove("hidden")
            successAlert.classList.add("hidden")

            // Scroll to error message
            errorAlert.scrollIntoView({ behavior: "smooth" })
          }
        })
        .catch((error) => {
          // Reset button state
          submitButton.innerHTML = originalButtonText
          submitButton.disabled = false

          console.error("Error:", error)
          errorMessage.textContent = "Terjadi kesalahan pada server."
          errorAlert.classList.remove("hidden")
          successAlert.classList.add("hidden")

          // Scroll to error message
          errorAlert.scrollIntoView({ behavior: "smooth" })
        })
    } else {
      // Show error message
      errorAlert.classList.remove("hidden")
      errorMessage.textContent = "Mohon lengkapi semua field yang wajib diisi."

      // Scroll to first error
      const firstError = document.querySelector(".text-red-500:not(.hidden)")
      if (firstError) {
        firstError.scrollIntoView({ behavior: "smooth", block: "center" })
      }
    }
  })

  // Input event listeners to hide error messages when changing
  const allInputs = document.querySelectorAll("input, textarea, select")
  allInputs.forEach((input) => {
    const eventType = input.tagName === "SELECT" ? "change" : "input"
    input.addEventListener(eventType, function () {
      const errorId = `${this.id}_error`
      const errorElement = document.getElementById(errorId)
      if (errorElement) {
        errorElement.classList.add("hidden")
      }
    })
  })

  // Close alerts
  closeAlert.addEventListener("click", () => {
    successAlert.classList.add("hidden")
  })

  closeErrorAlert.addEventListener("click", () => {
    errorAlert.classList.add("hidden")
  })
})
