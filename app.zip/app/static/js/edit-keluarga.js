document.addEventListener("DOMContentLoaded", () => {
  // RT/RW data mapping
  const rtRwData = {
    Sidopurno: {
      "01": ["01", "02", "03"],
      "02": ["01", "02", "03"],
      "03": ["01", "02", "03"],
    },
    Melaten: {
      "01": ["04"],
      "02": ["04"],
      "03": ["04"],
    },
    Ngepung: {
      "01": ["05"],
      "02": ["05"],
      "03": ["05"],
    },
    Duran: {
      "01": ["06"],
      "02": ["06"],
      "03": ["06"],
    },
    "Maten Perum Grenhill": {
      "01": ["07"],
      "02": ["07"],
      "03": ["07"],
    },
  }

  // Form elements
  const form = document.getElementById("editKeluargaForm")
  const dusunSelect = document.getElementById("dusun")
  const rtSelect = document.getElementById("rt")
  const rwSelect = document.getElementById("rw")
  const successAlert = document.getElementById("successAlert")
  const errorAlert = document.getElementById("errorAlert")
  const errorMessage = document.getElementById("errorMessage")
  const closeAlert = document.getElementById("closeAlert")
  const closeErrorAlert = document.getElementById("closeErrorAlert")

  // Populate form with existing data
  function populateForm() {
    // Get data from URL parameters
    const urlParams = new URLSearchParams(window.location.search)
    const dataParam = urlParams.get("data")

    if (dataParam) {
      try {
        const keluargaData = JSON.parse(decodeURIComponent(dataParam))

        if (keluargaData) {
          document.getElementById("keluarga_id").value = keluargaData.keluarga_id || ""
          document.getElementById("nama_kepala").value = keluargaData.nama_kepala || ""
          document.getElementById("alamat").value = keluargaData.alamat || ""
          document.getElementById("jumlah_anggota").value = keluargaData.jumlah_anggota || ""
          document.getElementById("jumlah_anggota_15plus").value = keluargaData.original_jumlah_anggota_15plus || ""

          // Set dusun and trigger change event to populate RT/RW
          if (keluargaData.dusun) {
            dusunSelect.value = keluargaData.dusun
            window.updateRTRWOptions()

            // Set RT after options are populated
            setTimeout(() => {
              if (keluargaData.rt) {
                rtSelect.value = keluargaData.rt
                window.updateRWOptions()

                // Set RW after options are populated
                setTimeout(() => {
                  if (keluargaData.rw) {
                    rwSelect.value = keluargaData.rw
                  }
                }, 100)
              }
            }, 100)
          }
        }
      } catch (error) {
        console.error("Error parsing family data:", error)
      }
    }
  }

  // Update RT/RW options based on selected dusun
  window.updateRTRWOptions = () => {
    const dusun = dusunSelect.value

    // Clear existing options
    rtSelect.innerHTML = '<option value="" disabled selected>Pilih RT</option>'
    rwSelect.innerHTML = '<option value="" disabled selected>Pilih RW</option>'

    // Disable RW until RT is selected
    rwSelect.disabled = true

    if (dusun && rtRwData[dusun]) {
      // Enable RT select
      rtSelect.disabled = false

      // Populate RT options
      Object.keys(rtRwData[dusun]).forEach((rt) => {
        const option = document.createElement("option")
        option.value = rt
        option.textContent = rt
        rtSelect.appendChild(option)
      })
    } else {
      rtSelect.disabled = true
    }
  }

  // Update RW options based on selected RT
  window.updateRWOptions = () => {
    const dusun = dusunSelect.value
    const rt = rtSelect.value

    // Clear existing options
    rwSelect.innerHTML = '<option value="" disabled selected>Pilih RW</option>'

    if (dusun && rt && rtRwData[dusun] && rtRwData[dusun][rt]) {
      // Enable RW select
      rwSelect.disabled = false

      // Populate RW options
      rtRwData[dusun][rt].forEach((rw) => {
        const option = document.createElement("option")
        option.value = rw
        option.textContent = rw
        rwSelect.appendChild(option)
      })
    } else {
      rwSelect.disabled = true
    }
  }

  // Form validation
  function validateForm() {
    let isValid = true
    const requiredFields = [
      { id: "dusun", errorId: "dusun_error" },
      { id: "rt", errorId: "rt_error" },
      { id: "rw", errorId: "rw_error" },
      { id: "nama_kepala", errorId: "nama_kepala_error" },
      { id: "alamat", errorId: "alamat_error" },
      { id: "jumlah_anggota", errorId: "jumlah_anggota_error" },
      { id: "jumlah_anggota_15plus", errorId: "jumlah_anggota_15plus_error" },
    ]

    // Check required fields
    requiredFields.forEach((field) => {
      const element = document.getElementById(field.id)
      const errorElement = document.getElementById(field.errorId)

      if (!element.value) {
        errorElement.classList.remove("hidden")
        isValid = false
      } else {
        errorElement.classList.add("hidden")
      }
    })

    // Additional validation for numeric fields
    const jumlahAnggota = Number.parseInt(document.getElementById("jumlah_anggota").value)
    const jumlahAnggota15plus = Number.parseInt(document.getElementById("jumlah_anggota_15plus").value)

    if (jumlahAnggota < 1) {
      document.getElementById("jumlah_anggota_error").textContent = "Jumlah anggota minimal 1"
      document.getElementById("jumlah_anggota_error").classList.remove("hidden")
      isValid = false
    }

    if (jumlahAnggota15plus < 0) {
      document.getElementById("jumlah_anggota_15plus_error").textContent = "Jumlah tidak boleh negatif"
      document.getElementById("jumlah_anggota_15plus_error").classList.remove("hidden")
      isValid = false
    }

    if (jumlahAnggota15plus > jumlahAnggota) {
      document.getElementById("jumlah_anggota_15plus_error").textContent =
        "Jumlah anggota 15+ tidak boleh lebih dari jumlah anggota"
      document.getElementById("jumlah_anggota_15plus_error").classList.remove("hidden")
      isValid = false
    }

    return isValid
  }

  // Form submission
  form.addEventListener("submit", async (e) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    // Show loading state
    const submitBtn = form.querySelector("button[type='submit']")
    const originalBtnText = submitBtn.innerHTML
    submitBtn.disabled = true
    submitBtn.innerHTML = `
      <div class="loading-spinner mr-2"></div>
      Menyimpan...
    `

    try {
      const formData = new FormData(form)

      const response = await fetch("/edit-family", {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (result.success) {
        // Show success message
        successAlert.classList.remove("hidden")

        // Redirect back to final page after delay
        setTimeout(() => {
          window.location.href = "/final"
        }, 2000)
      } else {
        // Show error message
        errorMessage.textContent = result.message
        errorAlert.classList.remove("hidden")
      }
    } catch (error) {
      // Show error message
      errorMessage.textContent = "Terjadi kesalahan: " + error.message
      errorAlert.classList.remove("hidden")
    } finally {
      // Restore button state
      submitBtn.disabled = false
      submitBtn.innerHTML = originalBtnText
    }
  })

  // Alert close handlers
  if (closeAlert) {
    closeAlert.addEventListener("click", () => {
      successAlert.classList.add("hidden")
    })
  }

  if (closeErrorAlert) {
    closeErrorAlert.addEventListener("click", () => {
      errorAlert.classList.add("hidden")
    })
  }

  // Initialize form
  populateForm()
})
