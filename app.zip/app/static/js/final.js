document.addEventListener("DOMContentLoaded", () => {
  // Set current date for readonly date fields
  const currentDate = new Date().toLocaleDateString("id-ID", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  })

  document.getElementById("tanggal_pencacah").value = currentDate
  document.getElementById("tanggal_pemberi_jawaban").value = currentDate

  // Get data from window object (passed from template)
  const allMembersData = window.allMembersData || []
  const familyData = window.keluargaData || {}

  // RT/RW data mapping
  const rtRwData = {
    Sidopurno: {
      "01": ["01", "02", "03"],
      "02": ["01", "02", "03"],
      "03": ["01", "02", "03"],
    },
    Melaten: {
      "01": ["04"],
      "02": ["04"],
      "03": ["04"],
    },
    Ngepung: {
      "01": ["05"],
      "02": ["05"],
      "03": ["05"],
    },
    Duran: {
      "01": ["06"],
      "02": ["06"],
      "03": ["06"],
    },
    "Maten Perum Grenhill": {
      "01": ["07"],
      "02": ["07"],
      "03": ["07"],
    },
  }

  // Edit functions for redirecting to edit pages
  window.editFamily = () => {
    const familyData = window.keluargaData || {}
    const params = new URLSearchParams({
      data: encodeURIComponent(JSON.stringify(familyData)),
    })
    window.location.href = `/edit-keluarga?${params.toString()}`
  }

  window.editMember = (index) => {
    const memberData = (window.allMembersData || [])[index]
    const familyData = window.keluargaData || {}
    const params = new URLSearchParams({
      memberIndex: index,
      memberData: encodeURIComponent(JSON.stringify(memberData)),
      familyData: encodeURIComponent(JSON.stringify(familyData)),
    })
    window.location.href = `/edit-anggota?${params.toString()}`
  }

  // Final form submission (existing code)
  document.getElementById("finalForm").addEventListener("submit", async function (e) {
    e.preventDefault()

    const formData = new FormData(this)

    try {
      const response = await fetch("/submit-final", {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (result.success) {
        document.getElementById("successAlert").classList.remove("hidden")
        if (result.download_url) {
          document.getElementById("downloadLink").href = result.download_url
        }
        if (result.redirect_url) {
          setTimeout(() => {
            window.location.href = result.redirect_url
          }, 3000)
        }
      } else {
        document.getElementById("errorMessage").textContent = result.message
        document.getElementById("errorAlert").classList.remove("hidden")
      }
    } catch (error) {
      document.getElementById("errorMessage").textContent = "Terjadi kesalahan: " + error.message
      document.getElementById("errorAlert").classList.remove("hidden")
    }
  })

  // Alert close handlers
  document.getElementById("closeAlert").addEventListener("click", () => {
    document.getElementById("successAlert").classList.add("hidden")
  })

  document.getElementById("closeErrorAlert").addEventListener("click", () => {
    document.getElementById("errorAlert").classList.add("hidden")
  })
})
